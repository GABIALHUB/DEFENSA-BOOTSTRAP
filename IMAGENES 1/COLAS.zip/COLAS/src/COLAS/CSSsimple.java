package COLAS;

public class CSSsimple {

}
