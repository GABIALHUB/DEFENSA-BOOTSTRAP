package COLAS;
import java.util.Scanner;
public class ProSnormal {

	public static void main(String[] args) {
		Snormal x=new Snormal(100);
		int n,i;Object da;
		Scanner leer=new Scanner(System.in);
		System.out.println("Ingrese elementos: ");
		n=leer.nextInt();
		for(i=1;i<n;i++) {
			da=new Integer(leer.nextInt());
			x.adicionar(da);
		}
		x.mostrar();
		Object max;
		int maxi,dai;
		Snormal aux=new Snormal(100);
		max=x.eliminar();maxi=max.hashCode();
		while(!x.esVacia()) {
			da=x.eliminar();
			aux.adicionar(da);
			dai=da.hashCode();
			if(dai>maxi) {
				maxi=dai;
				max=da;
			}
		}
		while(!aux.esVacia()) {
			da=aux.eliminar();
			if(da.equals(max)) {
				maxi=maxi+1;
				da=new Integer(maxi);
				x.adicionar(da);
			}
			else x.adicionar(da);
		}
		x.mostrar();
		System.out.println("");
	}
	

}
