package COLAS;

public abstract class Csssimple1 {
protected int ini, fin, max;
protected Object v[]=new Object[100];
Csssimple1(int ca)
{ini=0;fin=0;max=ca;}
abstract boolean esLlena();
abstract boolean esVacia();
abstract void adicionar(Object ele);
abstract Object eliminar();
abstract void mostrar();
abstract int nElem();
}
